# please ensure you have the wokwi vscode extension available

## press build in platfromio to build the files

## press ctrl + shift + p and then write wokwi:start simulation
