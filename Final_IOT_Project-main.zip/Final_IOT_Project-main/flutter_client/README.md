# flutter_client

## To resolve dependencies

```bash
flutter pub get
```

## to try the app run main.app
