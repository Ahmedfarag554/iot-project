enum TimeRange {
  year,
  month,
  day,
  hour,
}
